/*
 * Node class
 * 
 */function Node(data) {
    this.data = data;
    this.parent = null;
    this.children = [];
}